-- ============================================================
-- TeamHub — مخطط قاعدة البيانات (شغّله كاملاً في Supabase > SQL Editor)
-- كل الأسماء بادئتها th_ / th- حتى لا تتعارض مع جداول موقعك الحالي (profiles, messages ...)
-- لا يلمس أي جدول أو trigger أو policy موجود مسبقاً. آمن لإعادة التشغيل.
-- أول من يدخل TeamHub يصبح "المالك" (Owner).
-- ============================================================

-- 1) الملفات الشخصية
create table if not exists public.th_profiles (
  id           uuid primary key references auth.users(id) on delete cascade,
  display_name text not null,
  specialty    text check (specialty in ('frontend','backend','fullstack','mobile','ui_ux','devops','ai','qa')),
  bio          text check (bio is null or char_length(bio) <= 500),
  avatar_url   text,
  is_owner     boolean not null default false,
  onboarded    boolean not null default false,
  created_at   timestamptz not null default now()
);
alter table public.th_profiles enable row level security;

create or replace function public.th_is_owner()
returns boolean language sql stable security definer set search_path = public as $$
  select coalesce((select is_owner from public.th_profiles where id = auth.uid()), false)
$$;

drop policy if exists "th_profiles_select" on public.th_profiles;
create policy "th_profiles_select" on public.th_profiles for select to authenticated using (true);
drop policy if exists "th_profiles_update_own" on public.th_profiles;
create policy "th_profiles_update_own" on public.th_profiles for update to authenticated
  using (id = auth.uid()) with check (id = auth.uid());

-- لا إدخال مباشر، ولا تعديل لـ is_owner أبداً
revoke insert, update on public.th_profiles from authenticated, anon;
grant update (display_name, specialty, bio, avatar_url, onboarded) on public.th_profiles to authenticated;

-- ينشئ الملف الشخصي عند أول دخول (يستدعيها التطبيق). أول ملف = مالك
create or replace function public.th_ensure_profile(p_name text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'not authenticated'; end if;
  insert into public.th_profiles (id, display_name, is_owner)
  values (auth.uid(), coalesce(nullif(trim(p_name), ''), 'Member'),
          not exists (select 1 from public.th_profiles where is_owner))
  on conflict (id) do nothing;
end $$;
revoke all on function public.th_ensure_profile(text) from public, anon;
grant execute on function public.th_ensure_profile(text) to authenticated;

-- 2) المحادثة
create table if not exists public.th_messages (
  id         bigint generated always as identity primary key,
  user_id    uuid not null default auth.uid() references public.th_profiles(id) on delete cascade,
  content    text check (content is null or char_length(content) <= 2000),
  image_url  text,
  created_at timestamptz not null default now(),
  constraint th_messages_has_payload check (coalesce(trim(content), '') <> '' or image_url is not null)
);
create index if not exists th_messages_created_idx on public.th_messages (created_at desc);
alter table public.th_messages enable row level security;
drop policy if exists "th_messages_select" on public.th_messages;
create policy "th_messages_select" on public.th_messages for select to authenticated
  using (exists (select 1 from public.th_profiles where id = auth.uid()));
drop policy if exists "th_messages_insert" on public.th_messages;
create policy "th_messages_insert" on public.th_messages for insert to authenticated
  with check (user_id = auth.uid());
drop policy if exists "th_messages_delete" on public.th_messages;
create policy "th_messages_delete" on public.th_messages for delete to authenticated
  using (user_id = auth.uid() or public.th_is_owner());

-- 3) المهام + التثبيت للمالك فقط
create table if not exists public.th_tasks (
  id         bigint generated always as identity primary key,
  author_id  uuid not null default auth.uid() references public.th_profiles(id) on delete cascade,
  title      text not null check (char_length(title) between 1 and 160),
  body       text check (body is null or char_length(body) <= 4000),
  status     text not null default 'open' check (status in ('open','in_progress','done')),
  pinned     boolean not null default false,
  created_at timestamptz not null default now()
);
alter table public.th_tasks enable row level security;
drop policy if exists "th_tasks_select" on public.th_tasks;
create policy "th_tasks_select" on public.th_tasks for select to authenticated
  using (exists (select 1 from public.th_profiles where id = auth.uid()));
drop policy if exists "th_tasks_insert" on public.th_tasks;
create policy "th_tasks_insert" on public.th_tasks for insert to authenticated
  with check (author_id = auth.uid() and pinned = false);
drop policy if exists "th_tasks_update" on public.th_tasks;
create policy "th_tasks_update" on public.th_tasks for update to authenticated
  using (author_id = auth.uid() or public.th_is_owner()) with check (author_id = auth.uid() or public.th_is_owner());
drop policy if exists "th_tasks_delete" on public.th_tasks;
create policy "th_tasks_delete" on public.th_tasks for delete to authenticated
  using (author_id = auth.uid() or public.th_is_owner());

create or replace function public.th_guard_task_pin()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.pinned is distinct from old.pinned and not public.th_is_owner() then
    raise exception 'Only the owner can pin tasks';
  end if;
  new.author_id := old.author_id;
  return new;
end $$;
drop trigger if exists th_tasks_guard_pin on public.th_tasks;
create trigger th_tasks_guard_pin before update on public.th_tasks
  for each row execute function public.th_guard_task_pin();

create table if not exists public.th_task_replies (
  id         bigint generated always as identity primary key,
  task_id    bigint not null references public.th_tasks(id) on delete cascade,
  author_id  uuid not null default auth.uid() references public.th_profiles(id) on delete cascade,
  body       text not null check (char_length(body) between 1 and 2000),
  created_at timestamptz not null default now()
);
create index if not exists th_task_replies_idx on public.th_task_replies (task_id, created_at);
alter table public.th_task_replies enable row level security;
drop policy if exists "th_replies_select" on public.th_task_replies;
create policy "th_replies_select" on public.th_task_replies for select to authenticated
  using (exists (select 1 from public.th_profiles where id = auth.uid()));
drop policy if exists "th_replies_insert" on public.th_task_replies;
create policy "th_replies_insert" on public.th_task_replies for insert to authenticated
  with check (author_id = auth.uid());
drop policy if exists "th_replies_delete" on public.th_task_replies;
create policy "th_replies_delete" on public.th_task_replies for delete to authenticated
  using (author_id = auth.uid() or public.th_is_owner());

-- 4) الوقت الحقيقي
do $$ begin alter publication supabase_realtime add table public.th_messages;     exception when duplicate_object then null; end $$;
do $$ begin alter publication supabase_realtime add table public.th_tasks;        exception when duplicate_object then null; end $$;
do $$ begin alter publication supabase_realtime add table public.th_task_replies; exception when duplicate_object then null; end $$;

-- 5) التخزين (Buckets جديدة منفصلة)
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types) values
  ('th-avatars', 'th-avatars', true, 5242880, array['image/jpeg','image/png','image/webp','image/gif']),
  ('th-chat',    'th-chat',    true, 5242880, array['image/jpeg','image/png','image/webp','image/gif'])
on conflict (id) do update set public = true, file_size_limit = 5242880,
  allowed_mime_types = array['image/jpeg','image/png','image/webp','image/gif'];

do $$ declare b text; begin
  foreach b in array array['th-avatars','th-chat'] loop
    execute format('drop policy if exists "%s_read" on storage.objects', b);
    execute format('create policy "%s_read" on storage.objects for select using (bucket_id = %L)', b, b);
    execute format('drop policy if exists "%s_upload_own" on storage.objects', b);
    execute format('create policy "%s_upload_own" on storage.objects for insert to authenticated with check (bucket_id = %L and (storage.foldername(name))[1] = auth.uid()::text)', b, b);
    execute format('drop policy if exists "%s_delete_own" on storage.objects', b);
    execute format('create policy "%s_delete_own" on storage.objects for delete to authenticated using (bucket_id = %L and (storage.foldername(name))[1] = auth.uid()::text)', b, b);
  end loop;
end $$;
