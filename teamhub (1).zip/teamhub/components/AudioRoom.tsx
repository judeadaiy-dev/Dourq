'use client';
import { useEffect, useRef, useState } from 'react';
import type { RealtimeChannel } from '@supabase/supabase-js';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth';
import { Avatar, Button, Card, Eyebrow } from '@/components/ui/ui';
import { cn } from '@/lib/utils';

interface Member { id: string; name: string; avatar: string | null; muted: boolean; speaking: boolean }

export default function AudioRoom() {
  const { profile } = useAuth();
  const [members, setMembers] = useState<Member[]>([]);
  const [joined, setJoined] = useState(false);
  const [muted, setMuted] = useState(false);
  const [error, setError] = useState('');
  const ch = useRef<RealtimeChannel | null>(null);
  const stream = useRef<MediaStream | null>(null);
  const ctx = useRef<AudioContext | null>(null);
  const timer = useRef<ReturnType<typeof setInterval> | null>(null);
  const state = useRef({ muted: false, speaking: false });

  const track = () => profile && ch.current?.track({ id: profile.id, name: profile.display_name, avatar: profile.avatar_url, ...state.current });

  useEffect(() => {
    if (!profile) return;
    const c = supabase.channel('audio-room', { config: { presence: { key: profile.id } } });
    c.on('presence', { event: 'sync' }, () => setMembers(Object.values(c.presenceState<Member>()).map((a) => a[0] as Member))).subscribe();
    ch.current = c;
    return () => { stopMic(); supabase.removeChannel(c); };
  }, [profile?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  function stopMic() {
    if (timer.current) clearInterval(timer.current);
    stream.current?.getTracks().forEach((t) => t.stop());
    ctx.current?.close().catch(() => {});
    stream.current = null; ctx.current = null; timer.current = null;
  }

  async function join() {
    setError('');
    try {
      const s = await navigator.mediaDevices.getUserMedia({ audio: true });
      stream.current = s;
      const ac = new AudioContext(); ctx.current = ac;
      const an = ac.createAnalyser(); an.fftSize = 512;
      ac.createMediaStreamSource(s).connect(an);
      const buf = new Uint8Array(an.fftSize);
      state.current = { muted: false, speaking: false };
      timer.current = setInterval(() => {
        an.getByteTimeDomainData(buf);
        let sum = 0; for (const v of buf) { const d = (v - 128) / 128; sum += d * d; }
        const speaking = !state.current.muted && Math.sqrt(sum / buf.length) > 0.05;
        if (speaking !== state.current.speaking) { state.current.speaking = speaking; track(); }
      }, 150);
      setJoined(true); setMuted(false); track();
    } catch { setError('Microphone access was blocked. Allow it in the browser and try again.'); }
  }
  async function leave() { stopMic(); await ch.current?.untrack(); setJoined(false); }
  function toggleMute() {
    const m = !muted; setMuted(m); state.current = { muted: m, speaking: false };
    stream.current?.getAudioTracks().forEach((t) => (t.enabled = !m)); track();
  }

  return (
    <Card className="p-6">
      <div className="flex items-start justify-between gap-3">
        <div><Eyebrow>Audio room</Eyebrow><h3 className="display mt-2 text-2xl font-bold">Team voice room</h3></div>
        <span className="rounded-full border border-white/10 px-3 py-1 text-xs text-slate-400">{members.length} inside</span>
      </div>
      <div className="mt-5 flex min-h-[4rem] flex-wrap gap-4">
        {members.length === 0 && <p className="text-sm text-slate-500">Nobody is in the room yet.</p>}
        {members.map((m) => (
          <div key={m.id} className="flex flex-col items-center gap-2">
            <span className={cn('rounded-full p-[3px] transition', m.speaking ? 'bg-coral shadow-[0_0_20px_#FF5E36]' : 'bg-white/10')}><Avatar name={m.name} url={m.avatar} size={46} /></span>
            <span className="max-w-[4.5rem] truncate text-[11px] text-slate-400">{m.name}{m.muted ? ' 🔇' : ''}</span>
          </div>
        ))}
      </div>
      {error && <p className="mt-3 text-xs text-red-300">{error}</p>}
      <div className="mt-5 flex gap-3">
        {!joined ? <Button onClick={join}>Join room</Button> : (
          <>
            <Button variant="ghost" onClick={toggleMute}>{muted ? '🔇 Unmute' : '🎙 Mute'}</Button>
            <Button variant="ghost" onClick={leave}>Leave</Button>
          </>
        )}
      </div>
    </Card>
  );
}
