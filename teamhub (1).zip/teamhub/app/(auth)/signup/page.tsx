'use client';
import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { supabase } from '@/lib/supabase';
import { AuthShell, Button, Input } from '@/components/ui/ui';

export default function SignupPage() {
  const router = useRouter();
  const [err, setErr] = useState('');
  const [info, setInfo] = useState('');
  const [busy, setBusy] = useState(false);
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setBusy(true); setErr(''); setInfo('');
    const f = new FormData(e.currentTarget);
    const { data, error } = await supabase.auth.signUp({
      email: String(f.get('email')).trim(), password: String(f.get('password')),
      options: { data: { display_name: String(f.get('name')).trim() } }
    });
    if (error) { setErr(error.message); setBusy(false); return; }
    if (!data.session) { setInfo('Account created. Check your email to confirm it, then sign in.'); setBusy(false); return; }
    router.replace('/onboarding');
  }
  return (
    <AuthShell eyebrow="Join the team" title="Create your account.">
      <form onSubmit={submit} className="mt-7">
        <label className="block text-sm font-semibold">Your name<Input name="name" required placeholder="Alex Morgan" /></label>
        <label className="mt-4 block text-sm font-semibold">Email address<Input name="email" type="email" required placeholder="you@company.com" /></label>
        <label className="mt-4 block text-sm font-semibold">Password<Input name="password" type="password" required minLength={6} placeholder="At least 6 characters" /></label>
        <p className="mt-3 min-h-[1.25rem] text-xs text-red-300">{err}<span className="text-emerald-300">{info}</span></p>
        <Button type="submit" disabled={busy} className="mt-2 w-full">{busy ? 'Creating…' : 'Create account →'}</Button>
      </form>
      <p className="mt-6 text-center text-sm text-slate-400">Already a member? <Link href="/login" className="font-semibold text-coral">Sign in</Link></p>
    </AuthShell>
  );
}
