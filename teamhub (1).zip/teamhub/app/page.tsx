'use client';
import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/lib/auth';

export default function Home() {
  const { user, profile, loading } = useAuth();
  const router = useRouter();
  useEffect(() => {
    if (loading) return;
    if (!user) router.replace('/login');
    else if (profile && !profile.onboarded) router.replace('/onboarding');
    else if (profile) router.replace('/workspace');
  }, [loading, user, profile, router]);
  return <main className="flex min-h-screen items-center justify-center text-sm text-slate-500">Loading…</main>;
}
