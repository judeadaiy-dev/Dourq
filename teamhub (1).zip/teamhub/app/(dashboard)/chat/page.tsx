'use client';
import { useEffect, useRef, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth';
import { Avatar, Button, Card } from '@/components/ui/ui';
import { cn, fileExt } from '@/lib/utils';
import type { Message, Profile } from '@/lib/types';

export default function ChatPage() {
  const { profile } = useAuth();
  const [msgs, setMsgs] = useState<Message[]>([]);
  const [people, setPeople] = useState<Map<string, Profile>>(new Map());
  const [text, setText] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [status, setStatus] = useState('Live');
  const [notif, setNotif] = useState<NotificationPermission | 'unsupported'>('default');
  const peopleRef = useRef(people); peopleRef.current = people;
  const endRef = useRef<HTMLDivElement>(null);
  const meRef = useRef(profile?.id); meRef.current = profile?.id;

  useEffect(() => { setNotif(typeof Notification === 'undefined' ? 'unsupported' : Notification.permission); }, []);

  useEffect(() => {
    let alive = true;
    (async () => {
      const [p, m] = await Promise.all([
        supabase.from('th_profiles').select('*'),
        supabase.from('th_messages').select('*').order('created_at', { ascending: false }).limit(100)
      ]);
      if (!alive) return;
      setPeople(new Map(((p.data ?? []) as Profile[]).map((x) => [x.id, x])));
      setMsgs(((m.data ?? []) as Message[]).reverse());
      if (m.error) setStatus(m.error.message);
    })();
    const ch = supabase.channel('chat-room').on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'th_messages' }, async (pl) => {
      const m = pl.new as Message;
      if (!peopleRef.current.has(m.user_id)) {
        const { data } = await supabase.from('th_profiles').select('*').eq('id', m.user_id).maybeSingle();
        if (data) setPeople((prev) => new Map(prev).set(m.user_id, data as Profile));
      }
      setMsgs((prev) => (prev.some((x) => x.id === m.id) ? prev : [...prev, m]));
      if (m.user_id !== meRef.current && document.hidden && typeof Notification !== 'undefined' && Notification.permission === 'granted') {
        const n = peopleRef.current.get(m.user_id)?.display_name ?? 'TeamHub';
        new Notification(n, { body: m.content || '📷 Sent an image' });
      }
    }).subscribe();
    return () => { alive = false; supabase.removeChannel(ch); };
  }, []);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [msgs.length]);

  async function send(e: React.FormEvent) {
    e.preventDefault();
    if (!profile || (!text.trim() && !file)) return;
    setStatus(file ? 'Uploading…' : 'Sending…');
    let image_url: string | null = null;
    if (file) {
      const path = `${profile.id}/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${fileExt(file.name)}`;
      const up = await supabase.storage.from('th-chat').upload(path, file, { contentType: file.type });
      if (up.error) { setStatus(up.error.message); return; }
      image_url = supabase.storage.from('th-chat').getPublicUrl(path).data.publicUrl;
    }
    const { data, error } = await supabase.from('th_messages').insert({ content: text.trim() || null, image_url }).select('*').single();
    if (error) { setStatus(error.message); return; }
    setMsgs((prev) => (prev.some((x) => x.id === (data as Message).id) ? prev : [...prev, data as Message]));
    setText(''); setFile(null); setStatus('Live');
  }
  function pick(f?: File) {
    if (!f) return;
    if (!/^image\/(jpeg|png|webp|gif)$/.test(f.type)) return setStatus('Choose a JPG, PNG, WEBP or GIF image.');
    if (f.size > 5 * 1024 * 1024) return setStatus('Image must be under 5 MB.');
    setFile(f); setStatus('Live');
  }

  return (
    <Card className="flex h-[calc(100vh-14rem)] min-h-[28rem] flex-col overflow-hidden md:h-[calc(100vh-10rem)]">
      <div className="flex items-center justify-between border-b border-white/10 px-5 py-4">
        <div className="flex items-center gap-3"><i className="h-2 w-2 rounded-full bg-emerald-400 shadow-[0_0_12px_#34d399]" /><b className="display text-lg">Team chat</b></div>
        <div className="flex items-center gap-3">
          {notif === 'default' && <button onClick={async () => setNotif(await Notification.requestPermission())} className="text-xs font-semibold text-coral">🔔 Enable alerts</button>}
          <span className="text-xs text-slate-500">{status}</span>
        </div>
      </div>
      <div className="scroll-thin flex-1 space-y-3 overflow-y-auto px-5 py-5">
        {msgs.map((m) => {
          const mine = m.user_id === profile?.id; const a = people.get(m.user_id);
          return (
            <div key={m.id} className={cn('flex gap-3', mine && 'flex-row-reverse')}>
              <Avatar name={a?.display_name} url={a?.avatar_url} size={32} />
              <div className={cn('max-w-[78%] rounded-2xl border px-4 py-3 text-sm', mine ? 'border-coral/40 bg-coral/15' : 'border-white/10 bg-white/5')}>
                <p className={cn('text-[11px] font-semibold', mine ? 'text-orange-200' : 'text-slate-400')}>{mine ? 'You' : a?.display_name ?? 'Member'} · {new Date(m.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
                {m.image_url && (
                  <a href={m.image_url} target="_blank" rel="noopener noreferrer">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={m.image_url} alt="Shared" loading="lazy" className="mt-2 h-52 w-full max-w-xs rounded-xl object-cover" />
                  </a>
                )}
                {m.content && <p dir="auto" className="mt-1 whitespace-pre-wrap break-words leading-6 text-slate-100">{m.content}</p>}
              </div>
            </div>
          );
        })}
        <div ref={endRef} />
      </div>
      <form onSubmit={send} className="border-t border-white/10 p-4">
        {file && <p className="mb-3 text-xs text-slate-300"><span className="rounded-full border border-coral/30 bg-coral/10 px-3 py-1">🖼 {file.name}</span> <button type="button" onClick={() => setFile(null)} className="ml-2 text-slate-500 hover:text-white">✕</button></p>}
        <div className="flex items-center gap-2">
          <label className="cursor-pointer rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm transition hover:border-coral/50">📎<input type="file" accept="image/jpeg,image/png,image/webp,image/gif" className="hidden" onChange={(e) => { pick(e.target.files?.[0]); e.target.value = ''; }} /></label>
          <input dir="auto" maxLength={2000} value={text} onChange={(e) => setText(e.target.value)} placeholder="Write a message..." className="min-w-0 flex-1 rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white outline-none focus:border-coral" />
          <Button type="submit">Send</Button>
        </div>
      </form>
    </Card>
  );
}
